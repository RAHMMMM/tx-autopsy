export const TRANSFER:string;export const APPROVAL:string;
export function units(value:string|bigint,decimals?:number):string;
export function decode(tx:any,receipt:any):any;
export function rpc(method:string,params:any[]):Promise<any>;
