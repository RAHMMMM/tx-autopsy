# Tx Autopsy
A read-only Base transaction receipt inspector, using the neutral Tx Autopsy identity. This is an early receipt-inspection MVP, not a full trace debugger or security scanner.

## Run
Use Node 22.13 or newer. Run `npm run install:ci`, then `npm run dev`. Run `node --test tests/*.test.mjs` for decoding tests. Build using the Sites build helper documented in the plugin workflow (or `npm run build`).

## Data and boundaries
Server-side Base JSON-RPC reads `eth_chainId`, `eth_getTransactionByHash`, `eth_getTransactionReceipt`, and recent blocks for the example button. Default RPC is https://mainnet.base.org, intended for light validation traffic; configure a reliable provider before public-scale launch. Set `BASE_RPC_URL` as a server-only runtime environment variable in Sites. Do not commit provider keys. No database or wallet connection is required.

Decodes standard ERC-20/721-shaped Transfer and Approval logs. Known Base USDC and WETH addresses have fixed decimals. Unknown ERC-20 units remain raw. ERC-721-shaped logs display token IDs. Other events are counted but not decoded. Logs are evidence of emitted events, not independently proven balance changes. No internal traces, complete flow graph, full balances, swap inference, price feeds, or revert reasons. L1 fee is included only when returned by the receipt; otherwise fees are explicitly execution-only. Failed transactions are labeled reverted.

Requests validate fixed hashes; no user-selected URLs are fetched. Requests time out, errors are generic, dynamic content is escaped by React, and no secrets are rendered. The public RPC can be rate-limited. Before opening to large traffic add provider capacity, edge rate limiting, and caching. No mock market information is used. Decoder tests use isolated synthetic fixtures, not data displayed in the product.

## Deployment
Source is managed through Sites. `.openai/hosting.json` contains the selected project ID. Build with the Sites build helper, synchronize exact source using the Sites source workflow, and deploy the packaged version. New Sites are owner-private. Request public access explicitly when ready for external visitors.

## Sources
Ethereum JSON-RPC: https://ethereum.org/developers/docs/apis/json-rpc/
Base RPC status: https://status.base.org/
USDC Base address: https://developers.circle.com/stablecoins/usdc-contract-addresses
WETH Base predeploy: https://docs.base.org/base-chain/network-information
